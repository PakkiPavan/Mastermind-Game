# mock these functions from the stdlib

nowms() {
  :
}

mtime() {
  :
}

mmeasure() {
  :
}
